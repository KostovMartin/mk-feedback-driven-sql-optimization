﻿# Controlled Post-Hoc Analysis

Input directory: `experiment-runs\tpch-evaluation\tpch-sf1-mixed-20260522-213611`

Generated at: 2026-05-23T05:15:01.4481830Z

## Run Provenance

| Field | Value |
|-------|-------|
| Run ID | tpch-sf1-mixed-20260522-213611 |
| Candidate source | mixed |
| Model | qwen3.6:35b-a3b-q4_K_M |
| Scale factor | 1 |
| Workload manifest | /app/tpch/tpch-parameterized-mixed-corpus.json |
| Search parameter sets/query | 70 |
| Held-out parameter sets/query | 30 |
| Benchmark iterations | 1 |
| Minimum promotion pairs | 30 |
| Promotion alpha | 0.05 |
| Promotion improvement threshold % | 2.0 |
| Git commit | n/a |
| Git branch | n/a |
| Git dirty | n/a |

## Integrity

| Metric | Value |
|--------|-------|
| Benchmark rows | 660 |
| Valid pairs | 330 |
| Invalid pairs | 0 |
| Search pairs | 330 |
| Held-out pairs | 0 |
| Workload case rows | 22 |

## Workload Outcomes

| Status / outcome | Cases | Generated | Returned | Safety-passed | Search pairs | Held-out pairs | Failures |
|------------------|-------|-----------|----------|---------------|--------------|----------------|----------|
| completed / no_candidate | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| completed / no_validated_candidate | 6 | 6 | 6 | 6 | 0 | 0 | 0 |
| completed / candidate_pool | 11 | 11 | 11 | 11 | 330 | 0 | 0 |

## Candidate Funnel

| Stage | Count |
|-------|-------|
| Workload cases | 22 |
| Invocations | 22 |
| Candidates generated from workload cases | 18 |
| Candidates returned from workload cases | 17 |
| Candidates rejected from workload cases | 1 |
| Candidates after dedup from workload cases | 17 |
| Candidates after safety from workload cases | 17 |
| Candidate rows recorded | 17 |
| Safe candidates | 11 |
| Semantically validated candidates | 11 |
| Semantically failed candidates | 6 |
| Promoted candidates | 0 |
| Candidates rejected with reason | 0 |

## Candidate Source Breakdown

| Source | Detail | Candidates | Safe | Validated | Failed | Promoted | Validation rate % | Promotion rate % | Rejection reasons |
|--------|--------|------------|------|-----------|--------|----------|-------------------|------------------|-------------------|
| llm | llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 17 | 11 | 11 | 6 | 0 | 64.71 | 0.00 |  |

## Search-Phase Evidence

| Workload | Source | Pairs | Baseline median ms | Candidate median ms | Improvement % | p-value | 95% bootstrap CI % | Promotion status |
|----------|--------|-------|--------------------|---------------------|---------------|---------|--------------------|------------------|
| tpch_q03_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 285.89 | 282.76 | 1.09 | 0.001383 | -0.22 to 1.67 | pool |
| tpch_q07_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 255.01 | 497.43 | -95.07 | 1.000000 | -96.99 to -92.71 | pool |
| tpch_q10_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 260.18 | 264.75 | -1.76 | 0.634829 | -2.39 to 3.22 | pool |
| tpch_q11_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 68.29 | 73.89 | -8.21 | 0.742076 | -34.26 to 24.69 | pool |
| tpch_q12_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 296.83 | 294.00 | 0.96 | 0.078974 | -0.95 to 1.90 | pool |
| tpch_q15_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 454.22 | 912.61 | -100.92 | 1.000000 | -103.09 to -98.78 | pool |
| tpch_q17_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 715.63 | 1825.73 | -155.12 | 1.000000 | -161.60 to -149.78 | pool |
| tpch_q18_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 1759.00 | 1759.61 | -0.04 | 0.588212 | -2.31 to 2.01 | pool |
| tpch_q19_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 40.51 | 46.84 | -15.61 | 1.000000 | -24.33 to -8.09 | pool |
| tpch_q21_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 362.96 | 2758.65 | -660.05 | 1.000000 | -672.62 to -643.02 | pool |
| tpch_q22_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 39.98 | 39.75 | 0.56 | 0.686827 | -1.32 to 1.38 | pool |

## Held-Out Evidence

Not estimated: no valid held-out benchmark pairs were exported.

## Promoted Query Text

No promoted candidate SQL text was exported.

## H1 Improvement

Attempted templates used for hit-rate denominator: 22

Not estimated: no promoted candidate has held-out paired measurements in this export.

## Equivalence Evidence

| Metric | Value |
|--------|-------|
| Equivalence checks | 17 |
| Passed checks | 11 |
| Failed checks | 6 |

| Method | Passed | Checks | Rows compared total | Rows compared median | Median execution ms |
|--------|--------|--------|---------------------|----------------------|---------------------|
| full_comparison | False | 6 | 0 | 0 | 0.00 |
| full_comparison | True | 11 | 3191 | 21 | 1992.07 |

Failed equivalence checks:

| Candidate | Method | Check type | Original rows | Candidate rows | Rows compared | Mismatch detail |
|-----------|--------|------------|---------------|----------------|---------------|-----------------|
| b61919f4-01a2-4faa-87e5-bc74c94d1054 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 9d60ae91-08b1-4d0f-91c1-17227c0b02de | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 6a9ff24b-2d03-4814-9143-d5aa432e5d7f | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 6662e7d6-a3a0-4173-9430-f3db29aaf77f | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| cd18feee-bd75-430b-961a-f679308395fd | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 50058ae5-ea6a-44b5-88e8-9f3cf7d0c0d5 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |

## Negative and Null Outcomes

Workload cases that did not produce a promoted outcome:

| Workload | Status / outcome | Failure stage | Failure reason | Generated | Returned | Safety-passed | Benchmark pairs |
|----------|------------------|---------------|----------------|-----------|----------|---------------|-----------------|
| tpch_q01_parameterized | completed / no_candidate |  |  | 1 | 0 | 0 | 0 |
| tpch_q02_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q03_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q04_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q05_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q06_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q07_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q08_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q09_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q10_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q11_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q12_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q13_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q14_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q15_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q16_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q17_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q18_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q19_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q20_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q21_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q22_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |

Rejected, failed, demoted, or evicted candidates:

| Candidate | Template | Source | Semantic status | Promotion status | Rejection reason |
|-----------|----------|--------|-----------------|------------------|------------------|
| b61919f4-01a2-4faa-87e5-bc74c94d1054 | c22cec7f78eaa7695f14de60a73d2ac647941991655e29adca0037e9c0f2787e | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 9d60ae91-08b1-4d0f-91c1-17227c0b02de | ec0c04e6293178d12a65d8735b22460d8a800f50527fc3c54559a1dcf4e11d1b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 6a9ff24b-2d03-4814-9143-d5aa432e5d7f | 35dfb3e538afdf28ec0525c957a014e320a3d6a9406eef297d2b2a90641a820b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 6662e7d6-a3a0-4173-9430-f3db29aaf77f | 8ba24aa502bb399e95bf96f526c18edbf7876f08c289a5a0e547f22ddf5e2349 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| cd18feee-bd75-430b-961a-f679308395fd | b43d1468a46ebe0c3972d6873d1f10efa1a05a531b006b26f7096128b2253825 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 50058ae5-ea6a-44b5-88e8-9f3cf7d0c0d5 | b500faac2de734a9dd2bb907891eef18d723b57c5473f883f9a42767a9b6f9e6 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |

## Monitoring Evidence

| Metric | Value |
|--------|-------|
| Monitoring enabled | True |
| Metrics path | metrics |
| Metrics files | 6 |

| File | Size bytes |
|------|------------|
| docker-containers.csv | 2296071 |
| gpu.csv | 296454 |
| host.csv | 333178 |
| monitoring-manifest.json | 7118 |
| prometheus-window.json | 7420 |
| rewrite-service.csv | 166616 |

## H2-H5 Status

| Hypothesis | Status | Reason |
|------------|--------|--------|
| H2 convergence | not_estimated | Convergence requires repeated non-deterministic invocations and a growing candidate pool. |
| H3 empirical regret | not_estimated | Empirical regret needs multiple benchmark-selection rounds over at least two validated candidates per template. |
| H4 model scale | candidate_source_summary_available | Model-scale claims require comparable local model runs at a fixed invocation budget. |
| H5 complementarity | plan_artifacts_available | Complementarity needs EXPLAIN/plan evidence and optional PostgreSQL planner-toggle probes. |

This report is a post-hoc analysis artifact. It does not turn a controlled pilot into a public benchmark result.
