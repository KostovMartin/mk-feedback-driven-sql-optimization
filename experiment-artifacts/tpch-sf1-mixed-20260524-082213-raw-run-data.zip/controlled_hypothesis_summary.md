﻿# Controlled Post-Hoc Analysis

Input directory: `D:\mk-feedback-driven-sql-optimization\experiment-runs\tpch-evaluation\tpch-sf1-mixed-20260524-082213`

Generated at: 2026-05-24T05:53:45.6086024Z

## Run Provenance

| Field | Value |
|-------|-------|
| Run ID | tpch-sf1-mixed-20260524-082213 |
| Candidate source | mixed |
| Model | qwen3.6:35b-a3b-q4_K_M |
| Scale factor | 1 |
| Workload manifest | /app/tpch/tpch-parameterized-mixed-corpus.json |
| Search parameter sets/query | 70 |
| Held-out parameter sets/query | 30 |
| Benchmark iterations | 1 |
| Minimum promotion pairs | 30 |
| Promotion alpha | 0.05 |
| Promotion improvement threshold % | 2.0 |

## Integrity

| Metric | Value |
|--------|-------|
| Benchmark rows | 600 |
| Valid pairs | 300 |
| Invalid pairs | 0 |
| Search pairs | 300 |
| Held-out pairs | 0 |
| Workload case rows | 22 |

## Workload Outcomes

| Status / outcome | Cases | Generated | Returned | Safety-passed | Search pairs | Held-out pairs | Failures |
|------------------|-------|-----------|----------|---------------|--------------|----------------|----------|
| completed / no_candidate | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| completed / no_validated_candidate | 10 | 10 | 10 | 10 | 0 | 0 | 0 |
| completed / candidate_pool | 10 | 10 | 10 | 10 | 300 | 0 | 0 |

## Candidate Funnel

| Stage | Count |
|-------|-------|
| Workload cases | 22 |
| Invocations | 22 |
| Candidates generated from workload cases | 21 |
| Candidates returned from workload cases | 20 |
| Candidates rejected from workload cases | 1 |
| Candidates after dedup from workload cases | 20 |
| Candidates after safety from workload cases | 20 |
| Candidate rows recorded | 20 |
| Safe candidates | 10 |
| Semantically validated candidates | 10 |
| Semantically failed candidates | 10 |
| Promoted candidates | 0 |
| Candidates rejected with reason | 0 |

## Candidate Source Breakdown

| Source | Detail | Candidates | Safe | Validated | Failed | Promoted | Validation rate % | Promotion rate % | Rejection reasons |
|--------|--------|------------|------|-----------|--------|----------|-------------------|------------------|-------------------|
| llm | llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 20 | 10 | 10 | 10 | 0 | 50.00 | 0.00 |  |

## Search-Phase Evidence

| Workload | Source | Pairs | Baseline median ms | Candidate median ms | Improvement % | p-value | 95% bootstrap CI % | Promotion status |
|----------|--------|-------|--------------------|---------------------|---------------|---------|--------------------|------------------|
| tpch_q03_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 329.24 | 327.50 | 0.53 | 0.320413 | -1.27 to 2.84 | pool |
| tpch_q06_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 223.39 | 214.87 | 3.81 | 0.023630 | -1.04 to 7.28 | pool |
| tpch_q08_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 201.35 | 201.55 | -0.10 | 0.459648 | -2.03 to 2.36 | pool |
| tpch_q10_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 291.33 | 302.63 | -3.88 | 0.149422 | -11.33 to 5.12 | pool |
| tpch_q11_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 72.90 | 85.14 | -16.80 | 0.564396 | -28.57 to 16.37 | pool |
| tpch_q12_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 303.28 | 301.45 | 0.60 | 0.524237 | -2.54 to 2.09 | pool |
| tpch_q17_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 638.84 | 1541.62 | -141.31 | 1.000000 | -145.39 to -135.80 | pool |
| tpch_q18_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 1672.65 | 3712.80 | -121.97 | 1.000000 | -126.24 to -119.08 | pool |
| tpch_q19_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 34.43 | 48.11 | -39.73 | 1.000000 | -63.61 to -16.58 | pool |
| tpch_q22_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 38.23 | 48.44 | -26.70 | 1.000000 | -27.52 to -25.30 | pool |

## Held-Out Evidence

Not estimated: no valid held-out benchmark pairs were exported.

## Promoted Query Text

No promoted candidate SQL text was exported.

## H1 Improvement

Attempted templates used for hit-rate denominator: 22

Not estimated: no promoted candidate has held-out paired measurements in this export.

## Equivalence Evidence

| Metric | Value |
|--------|-------|
| Equivalence checks | 20 |
| Passed checks | 10 |
| Failed checks | 10 |

| Method | Passed | Checks | Rows compared total | Rows compared median | Median execution ms |
|--------|--------|--------|---------------------|----------------------|---------------------|
| full_comparison | False | 10 | 328 | 0 | 0.00 |
| full_comparison | True | 10 | 2885 | 14 | 1542.31 |

Failed equivalence checks:

| Candidate | Method | Check type | Original rows | Candidate rows | Rows compared | Mismatch detail |
|-----------|--------|------------|---------------|----------------|---------------|-----------------|
| 745080fa-4939-410b-90ac-35031d06c0ba | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| df4c91f5-45b4-44a3-9504-c201a84dab97 | full_comparison | initial | 15 | 15 | 15 | {"reason": "ordered_rows_mismatch"} |
| f556eb3a-3c7c-44a4-b35e-c6547c318ade | full_comparison | initial | 12 | 12 | 12 | {"reason": "ordered_rows_mismatch"} |
| a623e1f8-4e84-40bc-b3a4-2cdbfc426053 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 90864c9e-f7e9-478d-ab2b-704a270db61a | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| ad68d7d5-7db6-47b8-bcdc-15d83b137042 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| e092b732-77b6-41dc-9b5e-833296ea6d32 | full_comparison | initial | 1 | 0 | 1 | {"side": "candidate", "reason": "query_execution_error", "message": "relation \"revenue\" does not exist\nLINE 17: ...AND total_revenue = (SELECT MAX(total_revenue) FROM revenue)\n                                                                ^", "error_type": "UndefinedTable"} |
| e6421cbd-77db-4139-81aa-0837bfc19f4a | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 4e3b682a-6f65-4665-a316-74fc47696957 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 6dc774bb-b9f7-41f1-ae9d-0ae03d141ff9 | full_comparison | initial | 300 | 300 | 300 | {"reason": "ordered_rows_mismatch"} |

## Negative and Null Outcomes

Workload cases that did not produce a promoted outcome:

| Workload | Status / outcome | Failure stage | Failure reason | Generated | Returned | Safety-passed | Benchmark pairs |
|----------|------------------|---------------|----------------|-----------|----------|---------------|-----------------|
| tpch_q01_parameterized | completed / no_candidate |  |  | 1 | 0 | 0 | 0 |
| tpch_q02_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q03_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q04_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q05_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q06_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q07_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q08_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q09_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q10_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q11_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q12_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q13_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q14_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q15_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q16_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q17_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q18_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q19_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q20_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q21_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q22_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |

Rejected, failed, demoted, or evicted candidates:

| Candidate | Template | Source | Semantic status | Promotion status | Rejection reason |
|-----------|----------|--------|-----------------|------------------|------------------|
| 745080fa-4939-410b-90ac-35031d06c0ba | c22cec7f78eaa7695f14de60a73d2ac647941991655e29adca0037e9c0f2787e | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| df4c91f5-45b4-44a3-9504-c201a84dab97 | c4eacc82d15c07abb7287958c3b4b243a9983de9b6c9cd2ac51300323d21f70b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| f556eb3a-3c7c-44a4-b35e-c6547c318ade | dedcfabc9aa4a4348343f3343dc63b94554caceb2b176059b84d834ee6683c1a | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| a623e1f8-4e84-40bc-b3a4-2cdbfc426053 | ec0c04e6293178d12a65d8735b22460d8a800f50527fc3c54559a1dcf4e11d1b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 90864c9e-f7e9-478d-ab2b-704a270db61a | 35dfb3e538afdf28ec0525c957a014e320a3d6a9406eef297d2b2a90641a820b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| ad68d7d5-7db6-47b8-bcdc-15d83b137042 | 8ba24aa502bb399e95bf96f526c18edbf7876f08c289a5a0e547f22ddf5e2349 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| e092b732-77b6-41dc-9b5e-833296ea6d32 | 29a021050127af608626e9490d99cc2f12186c302cbe1c0e9efefc9de51723f0 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| e6421cbd-77db-4139-81aa-0837bfc19f4a | b43d1468a46ebe0c3972d6873d1f10efa1a05a531b006b26f7096128b2253825 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 4e3b682a-6f65-4665-a316-74fc47696957 | b500faac2de734a9dd2bb907891eef18d723b57c5473f883f9a42767a9b6f9e6 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 6dc774bb-b9f7-41f1-ae9d-0ae03d141ff9 | 6ca2bfd8d2bbcd7aaf6fccd43bb8a6f8a2a9f34416cf46d8672e02415997e479 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |

## Monitoring Evidence

| Metric | Value |
|--------|-------|
| Monitoring enabled | True |
| Metrics path | metrics |
| Metrics files | 6 |

| File | Size bytes |
|------|------------|
| docker-containers.csv | 1676198 |
| gpu.csv | 207180 |
| host.csv | 242557 |
| monitoring-manifest.json | 7117 |
| prometheus-window.json | 7420 |
| rewrite-service.csv | 120032 |

## H2-H5 Status

| Hypothesis | Status | Reason |
|------------|--------|--------|
| H2 convergence | not_estimated | Convergence requires repeated non-deterministic invocations and a growing candidate pool. |
| H3 empirical regret | not_estimated | Empirical regret needs multiple benchmark-selection rounds over at least two validated candidates per template. |
| H4 model scale | candidate_source_summary_available | Model-scale claims require comparable local model runs at a fixed invocation budget. |
| H5 complementarity | plan_artifacts_available | Complementarity needs EXPLAIN/plan evidence and optional PostgreSQL planner-toggle probes. |

This report is a post-hoc analysis artifact. It does not turn a controlled pilot into a public benchmark result.
