﻿# Controlled Post-Hoc Analysis

Input directory: `D:\mk-feedback-driven-sql-optimization\experiment-runs\tpch-evaluation\tpch-sf1-mixed-20260523-093915`

Generated at: 2026-05-23T07:08:51.5040800Z

## Run Provenance

| Field | Value |
|-------|-------|
| Run ID | tpch-sf1-mixed-20260523-093915 |
| Candidate source | mixed |
| Model | qwen3.6:35b-a3b-q4_K_M |
| Scale factor | 1 |
| Workload manifest | /app/tpch/tpch-parameterized-mixed-corpus.json |
| Search parameter sets/query | 70 |
| Held-out parameter sets/query | 30 |
| Benchmark iterations | 1 |
| Minimum promotion pairs | 30 |
| Promotion alpha | 0.05 |
| Promotion improvement threshold % | 2.0 |

## Integrity

| Metric | Value |
|--------|-------|
| Benchmark rows | 540 |
| Valid pairs | 270 |
| Invalid pairs | 0 |
| Search pairs | 270 |
| Held-out pairs | 0 |
| Workload case rows | 22 |

## Workload Outcomes

| Status / outcome | Cases | Generated | Returned | Safety-passed | Search pairs | Held-out pairs | Failures |
|------------------|-------|-----------|----------|---------------|--------------|----------------|----------|
| completed / no_candidate | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| completed / no_validated_candidate | 11 | 11 | 11 | 11 | 0 | 0 | 0 |
| completed / candidate_pool | 9 | 9 | 9 | 9 | 270 | 0 | 0 |

## Candidate Funnel

| Stage | Count |
|-------|-------|
| Workload cases | 22 |
| Invocations | 22 |
| Candidates generated from workload cases | 21 |
| Candidates returned from workload cases | 20 |
| Candidates rejected from workload cases | 1 |
| Candidates after dedup from workload cases | 20 |
| Candidates after safety from workload cases | 20 |
| Candidate rows recorded | 20 |
| Safe candidates | 9 |
| Semantically validated candidates | 9 |
| Semantically failed candidates | 11 |
| Promoted candidates | 0 |
| Candidates rejected with reason | 0 |

## Candidate Source Breakdown

| Source | Detail | Candidates | Safe | Validated | Failed | Promoted | Validation rate % | Promotion rate % | Rejection reasons |
|--------|--------|------------|------|-----------|--------|----------|-------------------|------------------|-------------------|
| llm | llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 20 | 9 | 9 | 11 | 0 | 45.00 | 0.00 |  |

## Search-Phase Evidence

| Workload | Source | Pairs | Baseline median ms | Candidate median ms | Improvement % | p-value | 95% bootstrap CI % | Promotion status |
|----------|--------|-------|--------------------|---------------------|---------------|---------|--------------------|------------------|
| tpch_q03_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 271.80 | 273.45 | -0.61 | 0.548387 | -1.54 to 0.48 | pool |
| tpch_q04_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 183.35 | 184.19 | -0.46 | 0.742076 | -1.50 to 0.42 | pool |
| tpch_q06_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 182.82 | 177.02 | 3.17 | 0.144683 | -0.64 to 5.96 | pool |
| tpch_q12_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 283.79 | 284.48 | -0.24 | 0.840802 | -1.78 to 0.54 | pool |
| tpch_q15_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 445.30 | 880.39 | -97.71 | 1.000000 | -103.13 to -95.54 | pool |
| tpch_q17_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 608.24 | 1440.86 | -136.89 | 1.000000 | -139.64 to -127.50 | pool |
| tpch_q18_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 1675.65 | 3454.02 | -106.13 | 1.000000 | -108.95 to -104.53 | pool |
| tpch_q19_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 36.21 | 42.09 | -16.25 | 0.999999 | -30.36 to -7.14 | pool |
| tpch_q21_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 331.67 | 333.16 | -0.45 | 0.271264 | -1.52 to 0.84 | pool |

## Held-Out Evidence

Not estimated: no valid held-out benchmark pairs were exported.

## Promoted Query Text

No promoted candidate SQL text was exported.

## H1 Improvement

Attempted templates used for hit-rate denominator: 22

Not estimated: no promoted candidate has held-out paired measurements in this export.

## Equivalence Evidence

| Metric | Value |
|--------|-------|
| Equivalence checks | 20 |
| Passed checks | 9 |
| Failed checks | 11 |

| Method | Passed | Checks | Rows compared total | Rows compared median | Median execution ms |
|--------|--------|--------|---------------------|----------------------|---------------------|
| full_comparison | False | 11 | 1028 | 0 | 0.00 |
| full_comparison | True | 9 | 513 | 6 | 1734.69 |

Failed equivalence checks:

| Candidate | Method | Check type | Original rows | Candidate rows | Rows compared | Mismatch detail |
|-----------|--------|------------|---------------|----------------|---------------|-----------------|
| 37da43d0-741a-40f5-be99-f5ed17985665 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| abc2c2fc-48b0-4f33-9658-525724057b90 | full_comparison | initial | 15 | 15 | 15 | {"reason": "ordered_rows_mismatch"} |
| e4d97f24-0a8e-4047-9fc1-be89d9a49c79 | full_comparison | initial | 12 | 12 | 12 | {"reason": "ordered_rows_mismatch"} |
| 192c50b8-b8f9-458c-bae3-b87851f85d00 | full_comparison | initial | 2 | 0 | 2 | {"side": "candidate", "reason": "query_execution_error", "message": "column \"l_suppkey\" does not exist\nLINE 5: JOIN supplier ON s_suppkey = l_suppkey\n                                     ^\nHINT:  Perhaps you meant to reference the column \"supplier.s_suppkey\".", "error_type": "UndefinedColumn"} |
| e7a25c91-4565-49c9-816c-b2bf0259696f | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 1ec87d4d-9e2a-4eb8-8feb-56b413712f44 | full_comparison | initial | 20 | 0 | 20 | {"side": "candidate", "reason": "query_execution_error", "message": "column \"cr.revenue\" must appear in the GROUP BY clause or be used in an aggregate function\nLINE 15:   cr.revenue AS revenue,\n           ^", "error_type": "GroupingError"} |
| b2f3530c-83ed-428e-8de3-c1f2dd2c17e2 | full_comparison | initial | 979 | 0 | 979 | {"side": "candidate", "reason": "query_execution_error", "message": "column \"t.val\" must appear in the GROUP BY clause or be used in an aggregate function\nLINE 17: HAVING SUM(ps.ps_supplycost * ps.ps_availqty) > t.val\n                                                         ^", "error_type": "GroupingError"} |
| 30354770-6c05-4cac-ab3a-4adcf5a622c8 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 1cb8448d-c45e-4a84-a823-748d6bb48e5b | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| d543aee7-4a9c-4374-be73-5c11a89e2eb6 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 1c42e478-777b-4371-ac79-5988cefb7737 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |

## Negative and Null Outcomes

Workload cases that did not produce a promoted outcome:

| Workload | Status / outcome | Failure stage | Failure reason | Generated | Returned | Safety-passed | Benchmark pairs |
|----------|------------------|---------------|----------------|-----------|----------|---------------|-----------------|
| tpch_q01_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q02_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q03_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q04_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q05_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q06_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q07_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q08_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q09_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q10_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q11_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q12_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q13_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q14_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q15_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q16_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q17_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q18_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q19_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q20_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q21_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q22_parameterized | completed / no_candidate |  |  | 1 | 0 | 0 | 0 |

Rejected, failed, demoted, or evicted candidates:

| Candidate | Template | Source | Semantic status | Promotion status | Rejection reason |
|-----------|----------|--------|-----------------|------------------|------------------|
| 37da43d0-741a-40f5-be99-f5ed17985665 | c22cec7f78eaa7695f14de60a73d2ac647941991655e29adca0037e9c0f2787e | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| abc2c2fc-48b0-4f33-9658-525724057b90 | c4eacc82d15c07abb7287958c3b4b243a9983de9b6c9cd2ac51300323d21f70b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| e4d97f24-0a8e-4047-9fc1-be89d9a49c79 | dedcfabc9aa4a4348343f3343dc63b94554caceb2b176059b84d834ee6683c1a | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 192c50b8-b8f9-458c-bae3-b87851f85d00 | 26905ae5bb1db0ad4d85cd45c47e840c79e0bada5c24d2efac6f2947e2d79d97 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| e7a25c91-4565-49c9-816c-b2bf0259696f | ec0c04e6293178d12a65d8735b22460d8a800f50527fc3c54559a1dcf4e11d1b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 1ec87d4d-9e2a-4eb8-8feb-56b413712f44 | 392d2c07e3e5b0933160d3d5b81742ef655a19626583260bb690f69b1a391f7a | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| b2f3530c-83ed-428e-8de3-c1f2dd2c17e2 | 06339d9197a4ee5fbdc344631b2a0b9af6252094944c27e1fd0855db9c377c7f | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 30354770-6c05-4cac-ab3a-4adcf5a622c8 | 35dfb3e538afdf28ec0525c957a014e320a3d6a9406eef297d2b2a90641a820b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 1cb8448d-c45e-4a84-a823-748d6bb48e5b | 8ba24aa502bb399e95bf96f526c18edbf7876f08c289a5a0e547f22ddf5e2349 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| d543aee7-4a9c-4374-be73-5c11a89e2eb6 | b43d1468a46ebe0c3972d6873d1f10efa1a05a531b006b26f7096128b2253825 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 1c42e478-777b-4371-ac79-5988cefb7737 | b500faac2de734a9dd2bb907891eef18d723b57c5473f883f9a42767a9b6f9e6 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |

## Monitoring Evidence

| Metric | Value |
|--------|-------|
| Monitoring enabled | True |
| Metrics path | metrics |
| Metrics files | 6 |

| File | Size bytes |
|------|------------|
| docker-containers.csv | 1581256 |
| gpu.csv | 195379 |
| host.csv | 229189 |
| monitoring-manifest.json | 7117 |
| prometheus-window.json | 7420 |
| rewrite-service.csv | 114182 |

## H2-H5 Status

| Hypothesis | Status | Reason |
|------------|--------|--------|
| H2 convergence | not_estimated | Convergence requires repeated non-deterministic invocations and a growing candidate pool. |
| H3 empirical regret | not_estimated | Empirical regret needs multiple benchmark-selection rounds over at least two validated candidates per template. |
| H4 model scale | candidate_source_summary_available | Model-scale claims require comparable local model runs at a fixed invocation budget. |
| H5 complementarity | plan_artifacts_available | Complementarity needs EXPLAIN/plan evidence and optional PostgreSQL planner-toggle probes. |

This report is a post-hoc analysis artifact. It does not turn a controlled pilot into a public benchmark result.
