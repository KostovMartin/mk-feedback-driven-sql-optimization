﻿# Controlled Post-Hoc Analysis

Input directory: `D:\mk-feedback-driven-sql-optimization\experiment-runs\tpch-evaluation\tpch-sf1-mixed-20260524-210900`

Generated at: 2026-05-24T18:46:03.2476873Z

## Run Provenance

| Field | Value |
|-------|-------|
| Run ID | tpch-sf1-mixed-20260524-210900 |
| Candidate source | mixed |
| Model | qwen3.6:35b-a3b-q4_K_M |
| Scale factor | 1 |
| Workload manifest | /app/tpch/tpch-parameterized-mixed-corpus.json |
| Search parameter sets/query | 70 |
| Held-out parameter sets/query | 30 |
| Benchmark iterations | 1 |
| Minimum promotion pairs | 30 |
| Promotion alpha | 0.05 |
| Promotion improvement threshold % | 2.0 |

## Integrity

| Metric | Value |
|--------|-------|
| Benchmark rows | 720 |
| Valid pairs | 360 |
| Invalid pairs | 0 |
| Search pairs | 330 |
| Held-out pairs | 30 |
| Workload case rows | 22 |

## Workload Outcomes

| Status / outcome | Cases | Generated | Returned | Safety-passed | Search pairs | Held-out pairs | Failures |
|------------------|-------|-----------|----------|---------------|--------------|----------------|----------|
| completed / no_candidate | 4 | 0 | 0 | 0 | 0 | 0 | 0 |
| completed / no_validated_candidate | 7 | 7 | 7 | 7 | 0 | 0 | 0 |
| completed / candidate_pool | 10 | 10 | 10 | 10 | 300 | 0 | 0 |
| completed / held_out_completed | 1 | 1 | 1 | 1 | 30 | 30 | 0 |

## Candidate Funnel

| Stage | Count |
|-------|-------|
| Workload cases | 22 |
| Invocations | 22 |
| Candidates generated from workload cases | 18 |
| Candidates returned from workload cases | 18 |
| Candidates rejected from workload cases | 0 |
| Candidates after dedup from workload cases | 18 |
| Candidates after safety from workload cases | 18 |
| Candidate rows recorded | 18 |
| Safe candidates | 11 |
| Semantically validated candidates | 11 |
| Semantically failed candidates | 7 |
| Promoted candidates | 1 |
| Candidates rejected with reason | 0 |

## Candidate Source Breakdown

| Source | Detail | Candidates | Safe | Validated | Failed | Promoted | Validation rate % | Promotion rate % | Rejection reasons |
|--------|--------|------------|------|-----------|--------|----------|-------------------|------------------|-------------------|
| llm | llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 18 | 11 | 11 | 7 | 1 | 61.11 | 5.56 |  |

## Search-Phase Evidence

| Workload | Source | Pairs | Baseline median ms | Candidate median ms | Improvement % | p-value | 95% bootstrap CI % | Promotion status |
|----------|--------|-------|--------------------|---------------------|---------------|---------|--------------------|------------------|
| tpch_q03_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 269.62 | 270.36 | -0.28 | 0.451613 | -0.87 to 0.81 | pool |
| tpch_q05_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 219.16 | 219.11 | 0.02 | 0.443597 | -0.54 to 0.73 | pool |
| tpch_q06_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 176.03 | 175.07 | 0.54 | 0.672281 | -4.68 to 3.77 | pool |
| tpch_q08_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 172.20 | 171.18 | 0.59 | 0.140043 | 0.00 to 1.83 | pool |
| tpch_q10_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 236.33 | 175.27 | 25.84 | 0.000000 | 18.55 to 27.57 | promoted |
| tpch_q11_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 57.48 | 71.66 | -24.68 | 0.855317 | -41.39 to 21.75 | pool |
| tpch_q12_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 280.90 | 278.62 | 0.81 | 0.110323 | -0.72 to 1.58 | pool |
| tpch_q17_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 618.80 | 1444.29 | -133.40 | 1.000000 | -136.15 to -130.93 | pool |
| tpch_q18_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 1657.07 | 3813.00 | -130.10 | 1.000000 | -131.33 to -127.97 | pool |
| tpch_q19_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 36.59 | 42.42 | -15.94 | 1.000000 | -28.19 to -7.15 | pool |
| tpch_q21_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 328.87 | 328.72 | 0.05 | 0.508083 | -1.06 to 0.40 | pool |

## Held-Out Evidence

| Workload | Source | Pairs | Baseline median ms | Candidate median ms | Improvement % | p-value | 95% bootstrap CI % | Decision | Result |
|----------|--------|-------|--------------------|---------------------|---------------|---------|--------------------|----------|--------|
| tpch_q10_parameterized | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | 30 | 251.22 | 188.49 | 24.97 | 0.000000 | 18.03 to 28.31 | promote | positive pilot evidence |

## Promoted Query Text

### tpch_q10_parameterized

| Field | Value |
|-------|-------|
| Candidate ID | 284d5646-cd58-47e2-a82f-a518706760ec |
| Template fingerprint | 392d2c07e3e5b0933160d3d5b81742ef655a19626583260bb690f69b1a391f7a |
| Query file | q10.sql |
| Source | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 |
| Decision reason | paired_statistical_evidence |

Original SQL:

``sql
SELECT
  c_custkey,
  c_name,
  SUM(l_extendedprice * (1 - l_discount)) AS revenue,
  c_acctbal,
  n_name,
  c_address,
  c_phone,
  c_comment
FROM customer, orders, lineitem, nation
WHERE c_custkey = o_custkey
  AND l_orderkey = o_orderkey
  AND o_orderdate >= $1::date
  AND o_orderdate < $1::date + INTERVAL '3 months'
  AND l_returnflag = 'R'
  AND c_nationkey = n_nationkey
GROUP BY c_custkey, c_name, c_acctbal, c_phone, n_name, c_address, c_comment
ORDER BY revenue DESC
LIMIT 20;

``

Promoted SQL:

``sql
SELECT
  c_custkey,
  c_name,
  sub.revenue,
  c_acctbal,
  n_name,
  c_address,
  c_phone,
  c_comment
FROM customer c
JOIN nation n
  ON c.c_nationkey = n.n_nationkey
JOIN (
    SELECT
      o_custkey,
      SUM(l_extendedprice * (1 - l_discount)) AS revenue
    FROM orders o
    JOIN lineitem l
      ON o_orderkey = l_orderkey
    WHERE o_orderdate >= $1::date
      AND o_orderdate < $1::date + INTERVAL '3 months'
      AND l_returnflag = 'R'
    GROUP BY o_custkey
) sub
  ON c_custkey = sub.o_custkey
ORDER BY sub.revenue DESC
LIMIT 20;
``

## H1 Improvement

Attempted templates used for hit-rate denominator: 22

| Workload | Pairs | Held-out improvement % | p-value | 95% bootstrap CI % | Result |
|----------|-------|------------------------|---------|--------------------|--------|
| tpch_q10_parameterized | 30 | 24.97 | 0.000000 | 18.03 to 28.31 | positive pilot evidence |

## Equivalence Evidence

| Metric | Value |
|--------|-------|
| Equivalence checks | 18 |
| Passed checks | 11 |
| Failed checks | 7 |

| Method | Passed | Checks | Rows compared total | Rows compared median | Median execution ms |
|--------|--------|--------|---------------------|----------------------|---------------------|
| full_comparison | False | 7 | 13 | 0 | 0.00 |
| full_comparison | True | 11 | 3179 | 15 | 1639.11 |

Failed equivalence checks:

| Candidate | Method | Check type | Original rows | Candidate rows | Rows compared | Mismatch detail |
|-----------|--------|------------|---------------|----------------|---------------|-----------------|
| 39b923e7-396a-4530-b116-c52d41bbab6a | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| ff34449f-6ab2-4e79-a36c-7985bea4225f | full_comparison | initial | 12 | 12 | 12 | {"reason": "ordered_rows_mismatch"} |
| cb8aff21-faf1-4012-9826-5466769b41d9 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| f987608c-6284-47bf-8ca3-f2120cd1d40f | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 5e6166f2-ba3a-4005-8ce3-5b05c77bf085 | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |
| 68ec6db3-83c6-44b5-a7b2-01cd9daeea4e | full_comparison | initial | 1 | 0 | 1 | {"side": "candidate", "reason": "query_execution_error", "message": "aggregate functions are not allowed in WHERE\nLINE 18:   SELECT MAX(total_revenue) FROM lineitem\n                  ^", "error_type": "GroupingError"} |
| 5e75ede4-34bb-4f42-9064-f5fd0380197f | full_comparison | initial | 0 | 0 | 0 | {"side": "original", "reason": "query_execution_error", "message": "only '%s', '%b', '%t' are allowed as placeholders, got '%''", "error_type": "ProgrammingError"} |

## Negative and Null Outcomes

Workload cases that did not produce a promoted outcome:

| Workload | Status / outcome | Failure stage | Failure reason | Generated | Returned | Safety-passed | Benchmark pairs |
|----------|------------------|---------------|----------------|-----------|----------|---------------|-----------------|
| tpch_q01_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q02_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q03_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q04_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q05_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q06_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q07_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q08_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q09_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q10_parameterized | completed / held_out_completed |  |  | 1 | 1 | 1 | 30 |
| tpch_q11_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q12_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q13_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q14_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q15_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q16_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |
| tpch_q17_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q18_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q19_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q20_parameterized | completed / no_validated_candidate |  |  | 1 | 1 | 1 | 0 |
| tpch_q21_parameterized | completed / candidate_pool |  |  | 1 | 1 | 1 | 30 |
| tpch_q22_parameterized | completed / no_candidate |  |  | 0 | 0 | 0 | 0 |

Rejected, failed, demoted, or evicted candidates:

| Candidate | Template | Source | Semantic status | Promotion status | Rejection reason |
|-----------|----------|--------|-----------------|------------------|------------------|
| 39b923e7-396a-4530-b116-c52d41bbab6a | c22cec7f78eaa7695f14de60a73d2ac647941991655e29adca0037e9c0f2787e | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| ff34449f-6ab2-4e79-a36c-7985bea4225f | dedcfabc9aa4a4348343f3343dc63b94554caceb2b176059b84d834ee6683c1a | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| cb8aff21-faf1-4012-9826-5466769b41d9 | ec0c04e6293178d12a65d8735b22460d8a800f50527fc3c54559a1dcf4e11d1b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| f987608c-6284-47bf-8ca3-f2120cd1d40f | 35dfb3e538afdf28ec0525c957a014e320a3d6a9406eef297d2b2a90641a820b | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 5e6166f2-ba3a-4005-8ce3-5b05c77bf085 | 8ba24aa502bb399e95bf96f526c18edbf7876f08c289a5a0e547f22ddf5e2349 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 68ec6db3-83c6-44b5-a7b2-01cd9daeea4e | 29a021050127af608626e9490d99cc2f12186c302cbe1c0e9efefc9de51723f0 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |
| 5e75ede4-34bb-4f42-9064-f5fd0380197f | b500faac2de734a9dd2bb907891eef18d723b57c5473f883f9a42767a9b6f9e6 | llm:llm:ollama:qwen3.6:35b-a3b-q4_K_M:candidate-1 | failed | pool |  |

## Monitoring Evidence

| Metric | Value |
|--------|-------|
| Monitoring enabled | True |
| Metrics path | metrics |
| Metrics files | 6 |

| File | Size bytes |
|------|------------|
| docker-containers.csv | 1974715 |
| gpu.csv | 244236 |
| host.csv | 285995 |
| monitoring-manifest.json | 7117 |
| prometheus-window.json | 7420 |
| rewrite-service.csv | 143037 |

## H2-H5 Status

| Hypothesis | Status | Reason |
|------------|--------|--------|
| H2 convergence | not_estimated | Convergence requires repeated non-deterministic invocations and a growing candidate pool. |
| H3 empirical regret | not_estimated | Empirical regret needs multiple benchmark-selection rounds over at least two validated candidates per template. |
| H4 model scale | candidate_source_summary_available | Model-scale claims require comparable local model runs at a fixed invocation budget. |
| H5 complementarity | plan_artifacts_available | Complementarity needs EXPLAIN/plan evidence and optional PostgreSQL planner-toggle probes. |

This report is a post-hoc analysis artifact. It does not turn a controlled pilot into a public benchmark result.
